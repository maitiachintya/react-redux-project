import './App.css';
import CounterTask from './components/CounterTask';

function App() {
  return (
    <div className="App">
      <CounterTask />
    </div>
  );
}

export default App;
